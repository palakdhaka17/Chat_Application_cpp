# Chat-Appication
A console based chat application using C++.

# Features: #
 * Sign up
 * Sign in
 * Inbox
 * Chat
 * Friend list
 * Add friend
 * Unfriend
 * See all users
 * Group Message
 * Logout

# Dependenices #
* GNU GCC 4.8.1 compiler or higher

# Steps to execute #
  
- [x] Copy the contents of <kbd> src </kbd> folder in your computer.
- [x] Compile the file <kbd> chat_application.cpp </kbd> on GNU GCC 4.8.1 or higher compiler.
- [x] Select option 1 to register on application and Fill necessary details as asked on console.
- [x] Select option 2 to sign in and follow the instructions displayed on console to use various features.



